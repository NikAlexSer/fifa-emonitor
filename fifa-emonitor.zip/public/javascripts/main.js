google.charts.load('current', {'packages':['corechart', 'bar']});
google.charts.setOnLoadCallback(drawStuff);

function drawStuff() {
    var chartDiv = document.getElementById('chart_div5');

    var data = new google.visualization.DataTable();
    data.addColumn('string', 'Страны');
    data.addColumn('number', 'Печаль');
    data.addColumn('number', 'Радость');
    data.addColumn('number', 'Страх');
    data.addColumn('number', 'Отвращение');
    data.addColumn('number', 'Гнев');

    data.addRows([
        ['RU', 8.2163, 20.3013, 3.801, 10.47895, 11.51665],
        ['FR', 23.385125000000006, 33.04941666666667, 9.008108333333332, 15.946433333333335, 13.35808333333333],
        ['SP', 18.362299999999994, 26.638827941176473, 9.502714705882347, 20.787857352941174, 12.436674999999997],
        ['EN', 19.003794945980417, 42.08237586522642, 7.593078373924316, 14.991822834645536, 13.94829934078006],
        ['PT', 14.899969892473102, 36.666264516129026, 8.5775505376344, 15.113996774193536, 12.993383870967753]
    ]);


    var materialOptions = {
        width: 900,
        height: 500,
        chart: {
            title: 'Эмоции по странам'
        },
        axes: {
            y: {
                distance: {label: '%'}, // Left y-axis.
            }
        }
    };


    function drawMaterialChart() {
        var materialChart = new google.charts.Bar(chartDiv);
        materialChart.draw(data, google.charts.Bar.convertOptions(materialOptions));
    }

    drawMaterialChart();
};


google.charts.load('current', {'packages':['line']});
google.charts.setOnLoadCallback(drawChart);

function drawChart() {

    var data = new google.visualization.DataTable();
    data.addColumn('string', '');
    data.addColumn('number', 'RU');
    data.addColumn('number', 'FR');
    data.addColumn('number', 'SP');
    data.addColumn('number', 'EN');
    data.addColumn('number', 'PT');

    data.addRows([
        ['Печаль', 8.2163, 23.385125000000006, 19.003794945980417, 19.003794945980417, 14.899969892473102],
        ['Радость', 20.301, 33.04941666666667, 26.638827941176473, 42.08237586522642, 36.666264516129026],
        ['Страх', 3.801, 9.008108333333332, 9.502714705882347, 7.593078373924316, 8.5775505376344],
        ['Отвращение', 10.47895, 15.946433333333335, 20.787857352941174, 14.991822834645536, 15.113996774193536],
        ['Гнев', 11.51665, 13.35808333333333, 12.436674999999997, 13.94829934078006, 12.993383870967753]
    ]);

    var options = {
        chart: {
            title: 'Обобщенный эмоциональный фон',
        },
        width: 900,
        height: 500
    };

    var chart = new google.charts.Line(document.getElementById('chart_div4'));

    chart.draw(data, google.charts.Line.convertOptions(options));
}


google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawSeriesChart);

function drawSeriesChart() {

    var data = google.visualization.arrayToDataTable([
        ['ID', 'Life Expectancy', 'lol'],
        ['Печаль', 8.2163+ 23.385125000000006+ 19.003794945980417+ 19.003794945980417+ 14.899969892473102, 1],
        ['Радость', 20.301+ 33.04941666666667+ 26.638827941176473+ 42.08237586522642+ 36.666264516129026, 2],
        ['Страх', 3.801+ 9.008108333333332+ 9.502714705882347+ 7.593078373924316+ 8.5775505376344, 3],
        ['Отвращение', 10.47895+ 15.946433333333335+ 20.787857352941174+ 14.991822834645536+ 15.113996774193536, 4],
        ['Гнев', 11.51665+ 13.35808333333333+ 12.436674999999997+ 13.94829934078006+ 12.993383870967753, 5]
    ]);

    var options = {
        title: 'Correlation between life expectancy, fertility rate ' +
        'and population of some world countries (2010)',
        hAxis: {title: 'Life Expectancy'},
        vAxis: {title: 'Fertility Rate'},
        bubble: {textStyle: {fontSize: 11}}
    };

    var chart = new google.visualization.BubbleChart(document.getElementById('chart_div3'));
    chart.draw(data, options);
}

google.charts.load('current', {packages: ['corechart', 'bar']});
google.charts.setOnLoadCallback(drawMaterial);

function drawMaterial() {
    var data = google.visualization.arrayToDataTable([
        ['Word', 'Counts'],
        ['world cup trophy', 16],
        ['youtube video fifa', 34],
        ['fifa world cup', 57],
        ['biggest sporting event', 23],
        ['pura vida fifa', 41]
    ]);

    var materialOptions = {
        chart: {
            title: 'Top5 Keywords'
        },
        hAxis: {
            title: 'Total Population',
            minValue: 0,
        },
        bars: 'horizontal'
    };
    var materialChart = new google.charts.Bar(document.getElementById('chart_div2'));
    materialChart.draw(data, materialOptions);
}





google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChartPie);

function drawChartPie() {
    var data = google.visualization.arrayToDataTable([
        ['Country', 'Number of tweets'],
        ['RU',     1017],
        ['EN',      2389],
        ['FR',  257],
        ['SP', 570],
        ['PT',    340]
    ]);

    var options = {
        title: 'Язык твитов',
        height: 500
    };

    var chart = new google.visualization.PieChart(document.getElementById('chart_div1'));

    chart.draw(data, options);
}

google.charts.load('current', {'packages':['corechart', 'bar']});
google.charts.setOnLoadCallback(drawStuffPosNeg);

function drawStuffPosNeg() {
    var chartDiv = document.getElementById('chart_div0');

    var data = new google.visualization.DataTable();
    data.addColumn('string', 'Страны');
    data.addColumn('number', 'Негатив');
    data.addColumn('number', 'Позитив');

    data.addRows([
        [ 'RU', 79.62555092574772, 36.423424325788343 ],
        [ 'FR', 91.48721034809721, 67.0857034060875 ],
        [ 'SP', 66.48267811876455, 25.954613225788343 ],
        [ 'EN', 80.68276798555178, 49.23423562365778 ],
        [ 'PT', 66.62523013251132, 33.29751821765778 ],
    ]);


    var materialOptions = {
        width: 900,
        height: 500,
        chart: {
            title: 'Тональность сообщений по странам'
        },
        axes: {
            y: {
                distance: {label: '%'}, // Left y-axis.
            }
        }
    };


    function drawMaterialChart() {
        var materialChart = new google.charts.Bar(chartDiv);
        materialChart.draw(data, google.charts.Bar.convertOptions(materialOptions));
    }

    drawMaterialChart();
};